function websiteVisits(response) {
    document.querySelector("#visits").textContent = response.value;
}