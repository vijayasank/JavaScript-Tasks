var gifImages = ["mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png",
"mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png","mario1.png","mario2.png","mario3.png","mario4.png"];

var currentFrame = 0; 
function changePicture(){
    document.getElementById("picture1").src = gifImages[currentFrame]; 
    currentFrame++; 
}

setInterval(changePicture,500);