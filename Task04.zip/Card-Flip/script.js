const card = document.querySelector(".card__inner");

card.addEventListener("click", function (e) {
  card.classList.toggle('is-flipped');
 
});

//--------------------------------------------
const c1 = document.querySelector(".c11");

c1.addEventListener("click", function (e) {
  c1.classList.toggle('is-flipped');
});
//--------------------------------------------
const ca = document.querySelector(".caa");

ca.addEventListener("click", function (e) {
  ca.classList.toggle('is-flipped');
});
//--------------------------------------------
const cz = document.querySelector(".czz");

cz.addEventListener("click", function (e) {
  cz.classList.toggle('is-flipped');
});
//---------------------------------------------
const zc = document.querySelector(".zzc");

zc.addEventListener("click", function (e) {
  zc.classList.toggle('is-flipped');
});
//--------------------------------------------
const ac = document.querySelector(".aac");

ac.addEventListener("click", function (e) {
  ac.classList.toggle('is-flipped');
});
//--------------------------------------------
const cae = document.querySelector(".caae");

cae.addEventListener("click", function (e) {
  cae.classList.toggle('is-flipped');
});
//--------------------------------------------
const v1 = document.querySelector(".v2");

v1.addEventListener("click", function (e) {
  v1.classList.toggle('is-flipped');
});
//--------------------------------------------
const v11 = document.querySelector(".v21");

v11.addEventListener("click", function (e) {
  v11.classList.toggle('is-flipped');
});//-------------------------------------------
const v111 = document.querySelector(".v211");

v111.addEventListener("click", function (e) {
  v111.classList.toggle('is-flipped');
});
mydiv.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv1.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv2.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv3.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv4.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv5.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv6.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv7.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv8.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv9.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }
mydiv10.onclick = function(e) { alert('x='+e.clientX  + ' ' +'y='+ e.clientY); }




//----------------------------------------------
function WhichButton(event) {
  console.log("You pressed button: " + event.button)
}


